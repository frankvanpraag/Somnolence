//
//  SomnolenceApp.swift
//  Somnolence
//
//  Created by Frank van Praag on 17/12/2024.
//

import SwiftUI
import UserNotifications
import AVFoundation
import BackgroundTasks

@main
struct SomnolenceApp: App {
    @UIApplicationDelegateAdaptor private var appDelegate: AppDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
    private var backgroundTaskID: UIBackgroundTaskIdentifier = .invalid
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
        // Set up notification delegate
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
        
        // Configure audio session for background playback
        do {
            try AVAudioSession.sharedInstance().setCategory(
                .playback,
                mode: .default,
                options: [.mixWithOthers, .duckOthers]
            )
            try AVAudioSession.sharedInstance().setActive(true)
            
            // Enable background audio
            UIApplication.shared.beginReceivingRemoteControlEvents()
        } catch {
            print("Failed to set up audio session: \(error)")
        }
        
        // Request background fetch
        application.setMinimumBackgroundFetchInterval(UIApplication.backgroundFetchIntervalMinimum)
        
        // Enable background processing
        if #available(iOS 13.0, *) {
            BGTaskScheduler.shared.register(
                forTaskWithIdentifier: "com.yourapp.alarm.refresh",
                using: nil
            ) { task in
                self.handleBackgroundTask(task as! BGAppRefreshTask)
            }
        }
        
        return true
    }
    
    // Handle background fetch
    func application(_ application: UIApplication, performFetchWithCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        checkPendingAlarms()
        completionHandler(.newData)
    }
    
    // Handle background task expiration
    func applicationDidEnterBackground(_ application: UIApplication) {
        startBackgroundTask()
    }
    
    private func startBackgroundTask() {
        // End previous task if any
        if backgroundTaskID != .invalid {
            UIApplication.shared.endBackgroundTask(backgroundTaskID)
            backgroundTaskID = .invalid
        }
        
        // Start new background task
        backgroundTaskID = UIApplication.shared.beginBackgroundTask { [weak self] in
            self?.endBackgroundTask()
        }
    }
    
    private func endBackgroundTask() {
        if backgroundTaskID != .invalid {
            UIApplication.shared.endBackgroundTask(backgroundTaskID)
            backgroundTaskID = .invalid
        }
    }
    
    private func checkPendingAlarms() {
        // Load alarms and check for any that should be triggered
        if let savedAlarms = UserDefaults.standard.data(forKey: "SavedAlarms"),
           let alarms = try? JSONDecoder().decode([Alarm].self, from: savedAlarms) {
            
            for alarm in alarms {
                if let snoozedUntil = alarm.snoozedUntil, snoozedUntil > Date() {
                    scheduleLocalNotification(for: alarm, at: snoozedUntil)
                }
            }
        }
    }
    
    private func scheduleLocalNotification(for alarm: Alarm, at date: Date) {
        let content = UNMutableNotificationContent()
        content.title = "Wake Up!"
        content.body = "Time to rise and shine"
        content.sound = UNNotificationSound(named: UNNotificationSoundName("\(alarm.soundName).wav"))
        content.userInfo = ["soundName": alarm.soundName, "alarmId": alarm.id.uuidString]
        content.categoryIdentifier = "ALARM_CATEGORY"
        
        if #available(iOS 15.0, *) {
            content.interruptionLevel = .timeSensitive
        }
        
        let trigger = UNTimeIntervalNotificationTrigger(
            timeInterval: date.timeIntervalSinceNow,
            repeats: false
        )
        
        let request = UNNotificationRequest(
            identifier: "alarm-\(alarm.id)",
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request)
    }
    
    private func handleBackgroundTask(_ task: BGAppRefreshTask) {
        // Schedule next background task
        scheduleBackgroundTask()
        
        // Check and update alarms
        checkPendingAlarms()
        
        task.setTaskCompleted(success: true)
    }
    
    private func scheduleBackgroundTask() {
        let request = BGAppRefreshTaskRequest(identifier: "com.yourapp.alarm.refresh")
        request.earliestBeginDate = Date(timeIntervalSinceNow: 60) // Schedule for 1 minute later
        
        do {
            try BGTaskScheduler.shared.submit(request)
        } catch {
            print("Could not schedule background task: \(error)")
        }
    }
}
